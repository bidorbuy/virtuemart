<?php

/**
 * Copyright (c) 2014, 2015, 2016 Bidorbuy http://www.bidorbuy.co.za
 * This software is the proprietary information of Bidorbuy.
 *
 * All Rights Reserved.
 * Modification, redistribution and use in source and binary forms, with or without modification
 * are not permitted without prior written approval by the copyright holder.
 *
 * Vendor: EXTREME IDEA LLC http://www.extreme-idea.com
 */

use com\extremeidea\bidorbuy\storeintegrator\core as bobsi;

require_once(JPATH_ADMINISTRATOR . '/components/com_bidorbuystoreintegrator/vendor/autoload.php');

class VmController extends VmControllerDefault {
    private $bidorbuyStoreIntegrator;
    private $virtueMartProduct;

    public function __construct($cidName = 'cid', $config = array()) {
        $this->bidorbuyStoreIntegrator = new bobsi\Core();
        $this->virtueMartProduct = VmModel::getModel('product');

        $version = new JVersion();
        $dbSettings = array(
            bobsi\Db::SETTING_PREFIX => JFactory::getConfig()->getValue('config.dbprefix'),
            bobsi\Db::SETTING_SERVER => JFactory::getConfig()->getValue('config.host'),
            bobsi\Db::SETTING_USER => JFactory::getConfig()->getValue('config.user'),
            bobsi\Db::SETTING_PASS => JFactory::getConfig()->getValue('config.password'),
            bobsi\Db::SETTING_DBNAME => JFactory::getConfig()->getValue('config.db')
        );
        $this->bidorbuyStoreIntegrator->init(JFactory::getConfig()->getValue('config.sitename'), JFactory::getConfig()->getValue('config.mailfrom'), $version->PRODUCT . ' ' . $version->RELEASE . '.' . $version->DEV_LEVEL . '.' . $version->DEV_STATUS, JComponentHelper::getParams('com_bidorbuystoreintegrator')->get(bobsi\Settings::name), $dbSettings);

        parent::__construct($cidName, $config);
    }

    public function setRedirect($url, $msg = null, $type = null) {
        if (!$this->isThereAnyError()) {
            $this->processItem(JFactory::getApplication()->input->get('view'), $url);
        } else {
            JLog::add('BidorbuyStoreIntegrator: ' . $msg, $type);
        }

        parent::setRedirect($url, $msg, $type);
    }

    private function isThereAnyError() {
        $errorPresent = false;

        $errors = JError::getErrors();
        if (!empty($errors)) {
            $errorPresent = true;
        }

        foreach (JFactory::getApplication()->getMessageQueue() as $error) {
            if ($error['type'] == 'error') {
                $errorPresent = true;
            }
        }

        return (boolean)$errorPresent;
    }

    private function processItem($viewName) {
        if (in_array(JFactory::getApplication()->input->get('task'), array('apply', 'save'))) {
            if (JFactory::getApplication()->input->get('virtuemart_product_id')) {
                $this->updateProductDependedOnItem($viewName);
            } else {
                if ($viewName == 'product') {
                    JFactory::getDbo()->setQuery($this->bidorbuyStoreIntegrator->getQueries()->getAddJobQueries(VmModel::getModel($viewName)->getId(), bobsi\Queries::STATUS_NEW));
                    JFactory::getDbo()->query();
                 } else {
                    $this->updateProductDependedOnItem($viewName);
                }
            }
        }

        if (JFactory::getApplication()->input->get('task') == 'publish') {
            if ($viewName == 'product') {
                foreach (JFactory::getApplication()->input->get('virtuemart_product_id', 0, 'ARRAY') as $p) {
                    $p = JFactory::getDbo()->escape($p);
                    JFactory::getDbo()->setQuery($this->bidorbuyStoreIntegrator->getQueries()->getSetJobsRowStatusQuery($p, bobsi\Queries::STATUS_DELETE, time()));
                    JFactory::getDbo()->query();
                }

            }
            $this->updateProductDependedOnItem($viewName);
        }

        if (JFactory::getApplication()->input->get('task') == 'unpublish' OR JFactory::getApplication()->input->get('task') == 'remove') {
            if ($viewName == 'product') {
                foreach (JFactory::getApplication()->input->get('virtuemart_product_id', 0, 'ARRAY') as $p) {
                    $p = JFactory::getDbo()->escape($p);
                    JFactory::getDbo()->setQuery($this->bidorbuyStoreIntegrator->getQueries()->getAddJobQueries($p, bobsi\Queries::STATUS_DELETE));
                    JFactory::getDbo()->query();
                }
            } else {
                $this->updateProductDependedOnItem($viewName);
            }
        }
    }

    private function updateProductDependedOnItem($objectName) {
        switch ($objectName) {
            case 'product':
                foreach (JFactory::getApplication()->input->get('virtuemart_product_id', 0, 'ARRAY') as $p) {
                    $p = JFactory::getDbo()->escape($p);
                    JFactory::getDbo()->setQuery($this->bidorbuyStoreIntegrator->getQueries()->getAddJobQueries($p, bobsi\Queries::STATUS_UPDATE));
                    JFactory::getDbo()->query();
                }
                break;
            case 'category':
                $cids = (JFactory::getApplication()->input->get('virtuemart_category_id')) ? array(JFactory::getApplication()->input->get('virtuemart_category_id')) : JFactory::getApplication()->input->get('cid', 0, 'ARRAY');
                foreach ($cids as $cid) {
                    foreach ($this->getProductsInCategory($cid) as $p) {
                        JFactory::getDbo()->setQuery($this->bidorbuyStoreIntegrator->getQueries()->getAddJobQueries($p, bobsi\Queries::STATUS_UPDATE));
                        JFactory::getDbo()->query();
                    }
                }
                break;
            case 'custom':
                $customIds = JFactory::getApplication()->input->get('virtuemart_custom_id', 0, 'ARRAY');
                foreach ($customIds as $customId) {
                    $customId = JFactory::getDbo()->escape($customId);
                    JFactory::getDbo()->setQuery('SELECT DISTINCT `virtuemart_product_id` FROM `#__virtuemart_product_customfields` WHERE `virtuemart_custom_id` = "' . $customId . '"');
                    foreach (JFactory::getDbo()->loadAssocList() as $pid) {
                        JFactory::getDbo()->setQuery($this->bidorbuyStoreIntegrator->getQueries()->getAddJobQueries($pid['virtuemart_product_id'], bobsi\Queries::STATUS_UPDATE));
                        JFactory::getDbo()->query();
                    }
                }
                break;
            case 'calc':
                require_once(JPATH_ADMINISTRATOR . '/components/com_bidorbuystoreintegrator/script.php');
                $x = new com_bidorbuyStoreIntegratorInstallerScript();
                JFactory::getDbo()->setQuery($x->getBidorbuyStoreIntegrator()->getQueries()->getTruncateJobsQuery());
                JFactory::getDbo()->query();
                $x->addAllProductsInQueue(true);
        }
    }

    private function getProductsInCategory($categoryId) {
        //Set (_noLimit = true) to avoid VirtueMart limit: Configuration->Templates "Frontend default items per list view"
        $isLimit = $this->virtueMartProduct->_noLimit;
        $this->virtueMartProduct->_noLimit = true;
        $productsIds = $this->virtueMartProduct->sortSearchListQuery(true, $categoryId);
        $this->virtueMartProduct->_noLimit = $isLimit;

        return $productsIds;
    }
}